
Nuborgh College - Secure Test Platform (Prototype)
--------------------------------------------------

Wat zit in dit pakket:
- index.html (single-page prototype)
- css/styles.css
- js/app.js (client-side prototype logic; uses localStorage)
- assets/logo.png (gebruikt door de site - uw aangeleverde logo)

Belangrijke waarschuwing:
Dit is een client-side prototype gemaakt om de gevraagde functionaliteiten te demonstreren.
Het gebruikt localStorage en bevat GEEN echte server-side authenticatie of encryptie.
Voor productiegebruik is een volledige serverimplementatie, veilige wachtwoordopslag, HTTPS, en AVG-compliance vereist.

Hoe te starten op uw computer (localhost):

1) Zorg dat u Python 3 heeft geïnstalleerd (3.7+).
   Open een terminal (Command Prompt / PowerShell / Terminal). Navigeer naar de map waarin u dit project heeft uitgepakt.

2) Start een eenvoudige HTTP-server (option A of B):

   Optie A (Python 3):
       python -m http.server 8000

   Optie B (indien Python is gekoppeld aan 'python3'):
       python3 -m http.server 8000

   Dit (start vanuit de projectroot waar index.html staat) serveert de bestanden op poort 8000.

3) Open uw browser en ga naar:
       http://localhost:8000

   U ziet dan de inlogpagina van de prototype-app.

Standaard accounts in de prototype (voor testen):
  - Beheerder (super-admin):
      Email: kurkthijs@gmail.com
      Wachtwoord: admin123
  - Docent:
      Email: teacher1@nuborgh.nl
      Wachtwoord: teach123
  - Leerling:
      Email: student1@nuborgh.nl
      Wachtwoord: stud123

Wachtwoord reset: volgens uw specificatie is automatische e-mail uitgeschakeld. Klik "Wachtwoord vergeten?" inloggen toont instructie.
Extra: de beheerder kan in de admin interface handmatig wachtwoorden resetten.

ZIP locatie:

