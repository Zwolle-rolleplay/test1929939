// Client-side prototype logic
// WARNING: This is a static client-side prototype storing data in localStorage.
// For production you MUST implement server-side auth, encrypted storage, HTTPS, and GDPR compliance.

const LS_KEY = "nuborgh_proto_v1";

function loadState(){
  const raw = localStorage.getItem(LS_KEY);
  if(raw) return JSON.parse(raw);
  // bootstrap minimal data
  const state = {
    maintenance:false,
    users:[
      {email:"kurkthijs@gmail.com", password:"admin123", role:"admin", fullName:"Thijs Kurk", id:"u_admin", classes:[],isSuper:true},
      {email:"teacher1@nuborgh.nl", password:"teach123", role:"teacher", fullName:"Anna Docent", id:"u_t1", classes:["Klas 1A"]},
      {email:"student1@nuborgh.nl", password:"stud123", role:"student", fullName:"Jan Leerling", id:"u_s1", classes:["Klas 1A"]}
    ],
    classes: [{id:"Klas 1A", name:"Klas 1A", students:["student1@nuborgh.nl"]}],
    tests:[], submissions:[], logs:[]
  };
  localStorage.setItem(LS_KEY, JSON.stringify(state));
  return state;
}
function saveState(s){ localStorage.setItem(LS_KEY, JSON.stringify(s)); }

let state = loadState();
let currentUser = null;

// Utilities
function logEvent(msg, extra={}){
  state.logs.unshift({ts:Date.now(), user: currentUser?currentUser.email:"system", msg, extra});
  saveState(state);
}

function showView(id){
  document.querySelectorAll('.view').forEach(v=>v.classList.add('hidden'));
  document.getElementById(id).classList.remove('hidden');
}

function renderLogin(){
  showView('loginView');
  document.getElementById('loginForm').onsubmit = e=>{
    e.preventDefault();
    const email = document.getElementById('loginEmail').value.trim();
    const pw = document.getElementById('loginPassword').value;
    if(state.maintenance){
      alert("De website is nu in onderhoud. Het kan nu niet gebruikt worden.");
      return;
    }
    const u = state.users.find(x=>x.email===email && x.password===pw);
    if(!u){ alert("Onjuiste inloggegevens."); return; }
    currentUser = u;
    logEvent("login");
    if(u.role==="admin") renderAdmin();
    if(u.role==="teacher") renderTeacher();
    if(u.role==="student") renderStudent();
  };
  document.getElementById('forgotPw').onclick = (e)=>{
    e.preventDefault();
    alert("Wachtwoord vergeten? Meld je bij een beheerder of docent om je wachtwoord opnieuw in te laten stellen.");
  };
}

// Admin
function renderAdmin(){
  showView('adminView');
  document.getElementById('logoutBtn').onclick = ()=>{
    currentUser=null; renderLogin();
  };
  document.getElementById('createUserBtn').onclick = ()=>openCreateUserModal();
  document.getElementById('viewLogsBtn').onclick = ()=>openLogsModal();
  document.getElementById('maintenanceToggle').textContent = state.maintenance? "Hef onderhoud op":"Zet onderhoud aan";
  document.getElementById('maintenanceToggle').onclick = ()=>{
    state.maintenance = !state.maintenance; saveState(state);
    logEvent("toggle_maintenance",{val:state.maintenance});
    alert(state.maintenance? "Website in onderhoud gezet.":"Onderhoud opgeheven.");
    renderAdmin();
  };
  renderUsersTable();
  renderClassesArea();
}

function renderUsersTable(){
  const table = document.getElementById('usersTable');
  table.innerHTML = "<tr><th>Naam</th><th>Email</th><th>Rol</th><th>Klassen</th><th>Acties</th></tr>";
  state.users.forEach(u=>{
    const tr = document.createElement('tr');
    tr.innerHTML = `<td>${u.fullName||''}</td><td>${u.email}</td><td>${u.role}</td><td>${(u.classes||[]).join(", ")}</td>
      <td>
        <button data-e="${u.email}" class="editUser">Bewerk</button>
        <button data-e="${u.email}" class="resetPw">Reset wachtwoord</button>
      </td>`;
    table.appendChild(tr);
  });
  table.querySelectorAll('.editUser').forEach(b=>{
    b.onclick = ()=>{ openEditUserModal(b.dataset.e); };
  });
  table.querySelectorAll('.resetPw').forEach(b=>{
    b.onclick = ()=>{ adminResetPassword(b.dataset.e); };
  });
}

function openCreateUserModal(){
  const modal = document.createElement('div'); modal.className='modal';
  modal.innerHTML = `<div class="card">
    <h3>Maak gebruiker</h3>
    <div class="form-row"><label>Volledige Naam<br/><input id="cu_name"></label></div>
    <div class="form-row"><label>Email<br/><input id="cu_email"></label></div>
    <div class="form-row"><label>Rol<br/><select id="cu_role"><option value="student">Leerling</option><option value="teacher">Docent</option><option value="admin">Beheerder</option></select></label></div>
    <div class="form-row"><label>Startwachtwoord<br/><input id="cu_pw" value="start123"></label></div>
    <div class="form-row"><label>Klassen (comma-separated)<br/><input id="cu_classes"></label></div>
    <div style="display:flex;gap:8px;margin-top:8px"><button id="cu_save">Opslaan</button><button id="cu_close" class="secondary">Sluiten</button></div>
  </div>`;
  document.body.appendChild(modal);
  modal.querySelector('#cu_close').onclick = ()=>modal.remove();
  modal.querySelector('#cu_save').onclick = ()=>{
    const name=modal.querySelector('#cu_name').value.trim();
    const email=modal.querySelector('#cu_email').value.trim();
    const role=modal.querySelector('#cu_role').value;
    const pw=modal.querySelector('#cu_pw').value;
    const classesRaw=modal.querySelector('#cu_classes').value.trim();
    if(!name||!email){ alert("Naam en email verplicht"); return; }
    if(state.users.find(x=>x.email===email)){ alert("Email bestaat al"); return; }
    const newU = {email, password:pw, role, fullName:name, id:"u_"+Date.now(), classes: classesRaw? classesRaw.split(",").map(s=>s.trim()):[]};
    state.users.push(newU); saveState(state);
    logEvent("create_user",{email,role});
    modal.remove(); renderAdmin();
  };
}

function openEditUserModal(email){
  const user = state.users.find(u=>u.email===email);
  if(!user) return alert("Gebruiker niet gevonden");
  const modal = document.createElement('div'); modal.className='modal';
  modal.innerHTML = `<div class="card">
    <h3>Bewerk gebruiker</h3>
    <div class="form-row"><label>Volledige Naam<br/><input id="eu_name" value="${user.fullName||''}"></label></div>
    <div class="form-row"><label>Email<br/><input id="eu_email" value="${user.email}"></label></div>
    <div class="form-row"><label>Rol<br/><select id="eu_role"><option ${user.role==='student'?'selected':''} value="student">Leerling</option><option ${user.role==='teacher'?'selected':''} value="teacher">Docent</option><option ${user.role==='admin'?'selected':''} value="admin">Beheerder</option></select></label></div>
    <div class="form-row"><label>Klassen (comma-separated)<br/><input id="eu_classes" value="${(user.classes||[]).join(', ')}"></label></div>
    <div style="display:flex;gap:8px;margin-top:8px"><button id="eu_save">Opslaan</button><button id="eu_close" class="secondary">Sluiten</button></div>
  </div>`;
  document.body.appendChild(modal);
  modal.querySelector('#eu_close').onclick = ()=>modal.remove();
  modal.querySelector('#eu_save').onclick = ()=>{
    user.fullName = modal.querySelector('#eu_name').value.trim();
    user.email = modal.querySelector('#eu_email').value.trim();
    user.role = modal.querySelector('#eu_role').value;
    user.classes = modal.querySelector('#eu_classes').value.trim()? modal.querySelector('#eu_classes').value.split(",").map(s=>s.trim()):[];
    saveState(state);
    logEvent("edit_user",{email:user.email});
    modal.remove(); renderAdmin();
  };
}

function adminResetPassword(email){
  const u = state.users.find(x=>x.email===email);
  if(!u) return alert("Gebruiker niet gevonden");
  const pw = prompt("Nieuw wachtwoord voor "+email, "nieuw123");
  if(!pw) return;
  u.password = pw; saveState(state);
  logEvent("admin_reset_pw",{email});
  alert("Wachtwoord aangepast.");
  renderAdmin();
}

function openLogsModal(){
  const modal = document.createElement('div'); modal.className='modal';
  modal.innerHTML = `<div class="card"><h3>Systeemlogs</h3><div style="max-height:400px;overflow:auto">${state.logs.map(l=>`<div class="small">${new Date(l.ts).toLocaleString()} - ${l.user} - ${l.msg}</div>`).join('')}</div><div style="margin-top:8px"><button id="closeLogs">Sluiten</button></div></div>`;
  document.body.appendChild(modal);
  modal.querySelector('#closeLogs').onclick = ()=>modal.remove();
}

// Classes area (simple)
function renderClassesArea(){
  const area = document.getElementById('classesArea');
  area.innerHTML = '<div class="small">Bestaande Klassen:</div><ul>'+ state.classes.map(c=>`<li>${c.id} (${c.students.length} leerlingen)</li>`).join('') + '</ul>';
}

// Teacher
function renderTeacher(){
  showView('teacherView');
  document.getElementById('logoutBtnT').onclick = ()=>{ currentUser=null; renderLogin(); };
  document.getElementById('createTestBtn').onclick = ()=>openCreateTestModal();
  renderTeacherTests();
}

function renderTeacherTests(){
  const el = document.getElementById('testsList');
  const myTests = state.tests.filter(t=>t.createdBy===currentUser.email);
  el.innerHTML = myTests.map(t=>`<div class="view"><b>${t.title}</b> - ${t.assignedTo? 'Assigned':'Draft'} <div style="margin-top:6px"><button data-id="${t.id}" class="runTest">Bekijk / Toewijzen</button></div></div>`).join('') || '<div class="small">Geen toetsen</div>';
  el.querySelectorAll('.runTest').forEach(b=>b.onclick = ()=>openTestEditor(b.dataset.id));
}

function openCreateTestModal(){
  const modal = document.createElement('div'); modal.className='modal';
  modal.innerHTML = `<div class="card"><h3>Nieuwe toets</h3>
    <div class="form-row"><label>Titel<br/><input id="nt_title"></label></div>
    <div class="form-row"><label>Tijdslimiet (minuten)<br/><input id="nt_time" type="number" value="60"></label></div>
    <div class="form-row"><label>Toewijzen aan (klassen, comma)<br/><input id="nt_assign"></label></div>
    <div style="display:flex;gap:8px;margin-top:8px"><button id="nt_save">Opslaan concept</button><button id="nt_pub" class="secondary">Publiceer</button><button id="nt_close" class="secondary">Sluiten</button></div>
  </div>`;
  document.body.appendChild(modal);
  modal.querySelector('#nt_close').onclick = ()=>modal.remove();
  modal.querySelector('#nt_save').onclick = ()=>{
    const t = {id:"t_"+Date.now(), title:modal.querySelector('#nt_title').value||'Nieuwe toets', timeMinutes:parseInt(modal.querySelector('#nt_time').value||60), createdBy:currentUser.email, questions:[], assignedTo:null};
    state.tests.push(t); saveState(state); logEvent("create_test",{id:t.id}); modal.remove(); renderTeacher();
  };
  modal.querySelector('#nt_pub').onclick = ()=>{
    const t = {id:"t_"+Date.now(), title:modal.querySelector('#nt_title').value||'Nieuwe toets', timeMinutes:parseInt(modal.querySelector('#nt_time').value||60), createdBy:currentUser.email, questions:[], assignedTo: modal.querySelector('#nt_assign').value.trim()? modal.querySelector('#nt_assign').value.split(",").map(s=>s.trim()):[]};
    state.tests.push(t); saveState(state); logEvent("publish_test",{id:t.id, assignedTo:t.assignedTo}); modal.remove(); renderTeacher();
  };
}

function openTestEditor(testId){
  const t = state.tests.find(x=>x.id===testId);
  const modal = document.createElement('div'); modal.className='modal';
  modal.innerHTML = `<div class="card"><h3>Toets: ${t.title}</h3>
    <div class="form-row"><label>Vragenlijst (tekstuele placeholder voor prototype)</label></div>
    <div class="form-row"><textarea class="textarea" id="qbox">${t.questions.map(q=>q.text).join("\n---\n")}</textarea></div>
    <div style="display:flex;gap:8px;margin-top:8px"><button id="saveQ">Opslaan</button><button id="assign" class="secondary">Her toewijzen</button><button id="closeX" class="secondary">Sluiten</button></div>
  </div>`;
  document.body.appendChild(modal);
  modal.querySelector('#closeX').onclick = ()=>modal.remove();
  modal.querySelector('#saveQ').onclick = ()=>{
    // simple: store the textarea as one open question
    t.questions = [{type:'open', text: modal.querySelector('#qbox').value}];
    saveState(state);
    logEvent("edit_test",{id:t.id});
    alert("Toets opgeslagen (prototype).");
  };
  modal.querySelector('#assign').onclick = ()=>{
    const assign = prompt("Toewijzen aan klassen (comma) of emails", (t.assignedTo||[]).join(", "));
    if(assign!==null){ t.assignedTo = assign.trim()? assign.split(",").map(s=>s.trim()):[]; saveState(state); logEvent("assign_test",{id:t.id, assignedTo:t.assignedTo}); alert("Toegekend."); renderTeacher(); modal.remove(); }
  };
}

// Student
function renderStudent(){
  showView('studentView');
  document.getElementById('logoutBtnS').onclick = ()=>{ currentUser=null; renderLogin(); };
  // list assigned tests
  const el = document.getElementById('studentTests');
  const assigned = state.tests.filter(t=> (t.assignedTo||[]).length===0 ? false : (t.assignedTo.includes(currentUser.email) || t.assignedTo.some(a=> a===currentUser.classes?.[0])));
  el.innerHTML = assigned.map(t=>`<div class="view"><b>${t.title}</b> - tijd: <span class="timer">${t.timeMinutes} min</span> <div style="margin-top:6px"><button data-id="${t.id}" class="startTest">Start toets</button></div></div>`).join('') || '<div class="small">Geen toegewezen toetsen</div>';
  el.querySelectorAll('.startTest').forEach(b=>b.onclick = ()=>startTest(b.dataset.id));
}

function startTest(testId){
  const t = state.tests.find(x=>x.id===testId);
  if(!t) return;
  // compute student-specific time (check submissions for extraTime)
  const extra = (t.extraTimePerUser && t.extraTimePerUser[currentUser.email])? t.extraTimePerUser[currentUser.email]:0;
  const totalSeconds = (t.timeMinutes + extra) * 60;
  openTestRunner(t, totalSeconds);
}

function openTestRunner(testObj, totalSeconds){
  const modal = document.createElement('div'); modal.className='modal'; modal.id='runnerModal';
  modal.innerHTML = `<div class="card"><h3>${testObj.title}</h3>
    <div class="small">Leerling: <b>${currentUser.fullName}</b></div>
    <div class="small">Timer: <span id="timerDisplay">${formatTime(totalSeconds)}</span></div>
    <div style="margin-top:8px"><textarea class="textarea" id="answerBox"></textarea></div>
    <div style="display:flex;gap:8px;margin-top:8px"><button id="submitTest">Indienen</button><button id="closeTest" class="secondary">Annuleren</button></div>
    <div class="small" style="margin-top:8px">Anti-copy & monitoring (prototype): kopiëren geplakt is geblokkeerd; tab-switches worden gemeld.</div>
  </div>`;
  document.body.appendChild(modal);
  // Prevent copy/paste and context menu inside the modal textarea
  const area = modal.querySelector('#answerBox');
  ['copy','cut','paste'].forEach(ev=> area.addEventListener(ev, e=> { e.preventDefault(); alert("Kopiëren/plakken is uitgeschakeld tijdens toetsen."); }));
  modal.querySelector('.card').addEventListener('contextmenu', e=> e.preventDefault());
  // Tab-switch monitoring (prototype): listen to visibilitychange
  let tabSwitchCount = 0;
  function onVis(){ if(document.hidden){ tabSwitchCount++; console.warn("Tab switch", tabSwitchCount); } }
  document.addEventListener('visibilitychange', onVis);
  // Timer
  let remaining = totalSeconds;
  const interval = setInterval(()=>{
    remaining--; document.getElementById('timerDisplay').textContent = formatTime(remaining);
    if(remaining<=0){ clearInterval(interval); autoSubmit(); }
  }, 1000);
  modal.querySelector('#submitTest').onclick = ()=>{ clearInterval(interval); submitNow(); };
  modal.querySelector('#closeTest').onclick = ()=>{ clearInterval(interval); document.removeEventListener('visibilitychange', onVis); modal.remove(); renderStudent(); };
  function autoSubmit(){ alert("Tijd is om. De toets wordt automatisch ingediend."); submitNow(); }
  function submitNow(){
    const sub = {id:"sub_"+Date.now(), testId:testObj.id, student:currentUser.email, name:currentUser.fullName, answers: modal.querySelector('#answerBox').value, ts:Date.now(), tabSwitches: tabSwitchCount};
    state.submissions.push(sub); saveState(state); logEvent("submit_test",{testId:testObj.id, student:currentUser.email, tabSwitches}); document.removeEventListener('visibilitychange', onVis); modal.remove(); renderStudent(); alert("Toets opgeslagen. Uw docent kan deze nu bekijken.");
  }
}

function formatTime(sec){
  if(sec<0) sec=0;
  const m = Math.floor(sec/60); const s = sec%60; return `${m.toString().padStart(2,'0')}:${s.toString().padStart(2,'0')}`;
}

// Start app
document.addEventListener('DOMContentLoaded', ()=>{
  renderLogin();
});
